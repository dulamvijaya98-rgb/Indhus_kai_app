// placeholder draggable sticker widget
class DraggableStickerWidget {}